"""Consultas e indicadores."""
