"""Extracción de fuentes oficiales."""
