"""Normalización y validación."""
